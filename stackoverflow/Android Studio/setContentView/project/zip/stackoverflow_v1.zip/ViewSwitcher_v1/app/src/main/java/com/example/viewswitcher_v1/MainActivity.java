package com.example.viewswitcher_v1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{

    Context thisContext;
    View activity_main;

    TextView activity_main_textview_1;
    View activity_1;
    TextView activity_1_textview_1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        thisContext = this;

        activity_main = LayoutInflater.from(getApplicationContext()).inflate(R.layout.activity_main,null);
        activity_main_textview_1 = activity_main.findViewById(R.id.activity_1_TextView_1);

        activity_1 = LayoutInflater.from(getApplicationContext()).inflate(R.layout.activity_1,null);
        activity_1_textview_1 = activity_1.findViewById(R.id.activity_1_TextView_1);

        Handler handler;
        Runnable runnable;

        runnable = new Runnable()
        {
            @Override
            public void run()
            {
                Runnable runnable2;
                Handler handler2;

                setContentView(R.layout.activity_1);
                runnable2 = new Runnable()
                {
                    @Override
                    public void run()
                    {
                            activity_1_textview_1.setText("");
                            activity_1_textview_1.append("Shoot"+"\n");


                        // setContentView(R.layout.activity_main);
                        activity_main_textview_1.setText("");
                        activity_main_textview_1.append("Changed."+"\n");
                    }
                };
                handler2 = new Handler();
                handler2.postDelayed(runnable2,4000);
            }
        };
        handler = new Handler();
        handler.postDelayed(runnable,2000);



    }
}